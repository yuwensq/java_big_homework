package Gobang.Client;

public class Client {
	public static void main(String[] args) {
		Controller.getInstance().start();
	}
}